export {getCurrentUser} from "@/lib/auth";
